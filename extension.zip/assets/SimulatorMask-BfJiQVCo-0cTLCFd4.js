var nt=Object.defineProperty;var J=o=>{throw TypeError(o)};var at=(o,t,e)=>t in o?nt(o,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):o[t]=e;var l=(o,t,e)=>at(o,typeof t!="symbol"?t+"":t,e),K=(o,t,e)=>t.has(o)||J("Cannot "+e);var n=(o,t,e)=>(K(o,t,"read from private field"),e?e.call(o):t.get(o)),x=(o,t,e)=>t.has(o)?J("Cannot add the same private member more than once"):t instanceof WeakSet?t.add(o):t.set(o,e),f=(o,t,e,r)=>(K(o,t,"write to private field"),r?r.call(o,e):t.set(o,e),e),N=(o,t,e)=>(K(o,t,"access private method"),e);/**
 * AI Motion - WebGL2 animated border with AI-style glow effects
 *
 * @author Simon<gaomeng1900@gmail.com>
 * @license MIT
 * @repository https://github.com/gaomeng1900/ai-motion
 */function tt(o,t,e,r){const s=Math.max(1,Math.min(o,t)),a=Math.min(e,20),R=Math.min(a+r,s),p=Math.min(R,Math.floor(o/2)),v=Math.min(R,Math.floor(t/2)),d=j=>j/o*2-1,w=j=>j/t*2-1,G=0,D=o,U=0,I=t,k=p,S=o-p,O=v,M=t-v,u=d(G),h=d(D),V=w(U),W=w(I),z=d(k),Y=d(S),b=w(O),L=w(M),_=0,Q=0,E=1,X=1,$=p/o,q=1-p/o,A=v/t,y=1-v/t,st=new Float32Array([u,V,h,V,u,b,u,b,h,V,h,b,u,L,h,L,u,W,u,W,h,L,h,W,u,b,z,b,u,L,u,L,z,b,z,L,Y,b,h,b,Y,L,Y,L,h,b,h,L]),it=new Float32Array([_,Q,E,Q,_,A,_,A,E,Q,E,A,_,y,E,y,_,X,_,X,E,y,E,X,_,A,$,A,_,y,_,y,$,A,$,y,q,A,E,A,q,y,q,y,E,A,E,y]);return{positions:st,uvs:it}}/**
 * AI Motion - WebGL2 animated border with AI-style glow effects
 *
 * @author Simon<gaomeng1900@gmail.com>
 * @license MIT
 * @repository https://github.com/gaomeng1900/ai-motion
 */function et(o,t,e){const r=o.createShader(t);if(!r)throw new Error("Failed to create shader");if(o.shaderSource(r,e),o.compileShader(r),!o.getShaderParameter(r,o.COMPILE_STATUS)){const s=o.getShaderInfoLog(r)||"Unknown shader error";throw o.deleteShader(r),new Error(s)}return r}function ct(o,t,e){const r=et(o,o.VERTEX_SHADER,t),s=et(o,o.FRAGMENT_SHADER,e),a=o.createProgram();if(!a)throw new Error("Failed to create program");if(o.attachShader(a,r),o.attachShader(a,s),o.linkProgram(a),!o.getProgramParameter(a,o.LINK_STATUS)){const i=o.getProgramInfoLog(a)||"Unknown link error";throw o.deleteProgram(a),o.deleteShader(r),o.deleteShader(s),new Error(i)}return o.deleteShader(r),o.deleteShader(s),a}const dt=`#version 300 es
precision lowp float;
in vec2 vUV;
out vec4 outColor;
uniform vec2 uResolution;
uniform float uTime;
uniform float uBorderWidth;
uniform float uGlowWidth;
uniform float uBorderRadius;
uniform vec3 uColors[4];
uniform float uGlowExponent;
uniform float uGlowFactor;
const float PI = 3.14159265359;
const float TWO_PI = 2.0 * PI;
const float HALF_PI = 0.5 * PI;
const vec4 startPositions = vec4(0.0, PI, HALF_PI, 1.5 * PI);
const vec4 speeds = vec4(-1.9, -1.9, -1.5, 2.1);
const vec4 innerRadius = vec4(PI * 0.8, PI * 0.7, PI * 0.3, PI * 0.1);
const vec4 outerRadius = vec4(PI * 1.2, PI * 0.9, PI * 0.6, PI * 0.4);
float random(vec2 st) {
return fract(sin(dot(st.xy, vec2(12.9898, 78.233))) * 43758.5453123);
}
vec2 random2(vec2 st) {
return vec2(random(st), random(st + 1.0));
}
float aaStep(float edge, float d) {
float width = fwidth(d);
return smoothstep(edge - width * 0.5, edge + width * 0.5, d);
}
float aaFract(float x) {
float f = fract(x);
float w = fwidth(x);
float smooth_f = f * (1.0 - smoothstep(1.0 - w, 1.0, f));
return smooth_f;
}
float sdRoundedBox(in vec2 p, in vec2 b, in float r) {
vec2 q = abs(p) - b + r;
return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r;
}
float getInnerGlow(vec2 p, vec2 b, float radius) {
float dist_x = b.x - abs(p.x);
float dist_y = b.y - abs(p.y);
float glow_x = smoothstep(radius, 0.0, dist_x);
float glow_y = smoothstep(radius, 0.0, dist_y);
return 1.0 - (1.0 - glow_x) * (1.0 - glow_y);
}
float getVignette(vec2 uv) {
vec2 vignetteUv = uv;
vignetteUv = vignetteUv * (1.0 - vignetteUv);
float vignette = vignetteUv.x * vignetteUv.y * 25.0;
vignette = pow(vignette, 0.16);
vignette = 1.0 - vignette;
return vignette;
}
float uvToAngle(vec2 uv) {
vec2 center = vec2(0.5);
vec2 dir = uv - center;
return atan(dir.y, dir.x) + PI;
}
void main() {
vec2 uv = vUV;
vec2 pos = uv * uResolution;
vec2 centeredPos = pos - uResolution * 0.5;
vec2 size = uResolution - uBorderWidth;
vec2 halfSize = size * 0.5;
float dBorderBox = sdRoundedBox(centeredPos, halfSize, uBorderRadius);
float border = aaStep(0.0, dBorderBox);
float glow = getInnerGlow(centeredPos, halfSize, uGlowWidth);
float vignette = getVignette(uv);
glow *= vignette;
float posAngle = uvToAngle(uv);
vec4 lightCenter = mod(startPositions + speeds * uTime, TWO_PI);
vec4 angleDist = abs(posAngle - lightCenter);
vec4 disToLight = min(angleDist, TWO_PI - angleDist) / TWO_PI;
float intensityBorder[4];
intensityBorder[0] = 1.0;
intensityBorder[1] = smoothstep(0.4, 0.0, disToLight.y);
intensityBorder[2] = smoothstep(0.4, 0.0, disToLight.z);
intensityBorder[3] = smoothstep(0.2, 0.0, disToLight.w) * 0.5;
vec3 borderColor = vec3(0.0);
for(int i = 0; i < 4; i++) {
borderColor = mix(borderColor, uColors[i], intensityBorder[i]);
}
borderColor *= 1.1;
borderColor = clamp(borderColor, 0.0, 1.0);
float intensityGlow[4];
intensityGlow[0] = smoothstep(0.9, 0.0, disToLight.x);
intensityGlow[1] = smoothstep(0.7, 0.0, disToLight.y);
intensityGlow[2] = smoothstep(0.4, 0.0, disToLight.z);
intensityGlow[3] = smoothstep(0.1, 0.0, disToLight.w) * 0.7;
vec4 breath = smoothstep(0.0, 1.0, sin(uTime * 1.0 + startPositions * PI) * 0.2 + 0.8);
vec3 glowColor = vec3(0.0);
glowColor += uColors[0] * intensityGlow[0] * breath.x;
glowColor += uColors[1] * intensityGlow[1] * breath.y;
glowColor += uColors[2] * intensityGlow[2] * breath.z;
glowColor += uColors[3] * intensityGlow[3] * breath.w * glow;
glow = pow(glow, uGlowExponent);
glow *= random(pos + uTime) * 0.1 + 1.0;
glowColor *= glow * uGlowFactor;
glowColor = clamp(glowColor, 0.0, 1.0);
vec3 color = mix(glowColor, borderColor + glowColor * 0.2, border);
float alpha = mix(glow, 1.0, border);
outColor = vec4(color, alpha);
}`,ht=`#version 300 es
in vec2 aPosition;
in vec2 aUV;
out vec2 vUV;
void main() {
vUV = aUV;
gl_Position = vec4(aPosition, 0.0, 1.0);
}`;/**
 * AI Motion - WebGL2 animated border with AI-style glow effects
 *
 * @author Simon<gaomeng1900@gmail.com>
 * @license MIT
 * @repository https://github.com/gaomeng1900/ai-motion
 */const lt=["rgb(57, 182, 255)","rgb(189, 69, 251)","rgb(255, 87, 51)","rgb(255, 214, 0)"];function ut(o){const t=o.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/);if(!t)throw new Error(`Invalid color format: ${o}`);const[,e,r,s]=t;return[parseInt(e)/255,parseInt(r)/255,parseInt(s)/255]}class ft{constructor(t={}){l(this,"element");l(this,"canvas");l(this,"options");l(this,"running",!1);l(this,"disposed",!1);l(this,"startTime",0);l(this,"lastTime",0);l(this,"rafId",null);l(this,"glr");l(this,"observer");this.options={width:t.width??600,height:t.height??600,ratio:t.ratio??window.devicePixelRatio??1,borderWidth:t.borderWidth??8,glowWidth:t.glowWidth??200,borderRadius:t.borderRadius??8,mode:t.mode??"light",...t},this.canvas=document.createElement("canvas"),this.options.classNames&&(this.canvas.className=this.options.classNames),this.options.styles&&Object.assign(this.canvas.style,this.options.styles),this.canvas.style.display="block",this.canvas.style.transformOrigin="center",this.canvas.style.pointerEvents="none",this.element=this.canvas,this.setupGL(),this.options.skipGreeting||this.greet()}start(){if(this.disposed)throw new Error("Motion instance has been disposed.");if(this.running)return;if(!this.glr){console.error("WebGL resources are not initialized.");return}this.running=!0,this.startTime=performance.now(),this.resize(this.options.width??600,this.options.height??600,this.options.ratio),this.glr.gl.viewport(0,0,this.canvas.width,this.canvas.height),this.glr.gl.useProgram(this.glr.program),this.glr.gl.uniform2f(this.glr.uResolution,this.canvas.width,this.canvas.height),this.checkGLError(this.glr.gl,"start: after initial setup");const t=()=>{if(!this.running||!this.glr)return;this.rafId=requestAnimationFrame(t);const e=performance.now();if(e-this.lastTime<1e3/32)return;this.lastTime=e;const s=(e-this.startTime)*.001;this.render(s)};this.rafId=requestAnimationFrame(t)}pause(){if(this.disposed)throw new Error("Motion instance has been disposed.");this.running=!1,this.rafId!==null&&cancelAnimationFrame(this.rafId)}dispose(){if(this.disposed)return;this.disposed=!0,this.running=!1,this.rafId!==null&&cancelAnimationFrame(this.rafId);const{gl:t,vao:e,positionBuffer:r,uvBuffer:s,program:a}=this.glr;e&&t.deleteVertexArray(e),r&&t.deleteBuffer(r),s&&t.deleteBuffer(s),t.deleteProgram(a),this.observer&&this.observer.disconnect(),this.canvas.remove()}resize(t,e,r){if(this.disposed)throw new Error("Motion instance has been disposed.");if(this.options.width=t,this.options.height=e,r&&(this.options.ratio=r),!this.running)return;const{gl:s,program:a,vao:i,positionBuffer:R,uvBuffer:p,uResolution:v}=this.glr,d=r??this.options.ratio??window.devicePixelRatio??1,w=Math.max(1,Math.floor(t*d)),G=Math.max(1,Math.floor(e*d));this.canvas.style.width=`${t}px`,this.canvas.style.height=`${e}px`,(this.canvas.width!==w||this.canvas.height!==G)&&(this.canvas.width=w,this.canvas.height=G),s.viewport(0,0,this.canvas.width,this.canvas.height),this.checkGLError(s,"resize: after viewport setup");const{positions:D,uvs:U}=tt(this.canvas.width,this.canvas.height,this.options.borderWidth*d,this.options.glowWidth*d);s.bindVertexArray(i),s.bindBuffer(s.ARRAY_BUFFER,R),s.bufferData(s.ARRAY_BUFFER,D,s.STATIC_DRAW);const I=s.getAttribLocation(a,"aPosition");s.enableVertexAttribArray(I),s.vertexAttribPointer(I,2,s.FLOAT,!1,0,0),this.checkGLError(s,"resize: after position buffer update"),s.bindBuffer(s.ARRAY_BUFFER,p),s.bufferData(s.ARRAY_BUFFER,U,s.STATIC_DRAW);const k=s.getAttribLocation(a,"aUV");s.enableVertexAttribArray(k),s.vertexAttribPointer(k,2,s.FLOAT,!1,0,0),this.checkGLError(s,"resize: after UV buffer update"),s.useProgram(a),s.uniform2f(v,this.canvas.width,this.canvas.height),s.uniform1f(this.glr.uBorderWidth,this.options.borderWidth*d),s.uniform1f(this.glr.uGlowWidth,this.options.glowWidth*d),s.uniform1f(this.glr.uBorderRadius,this.options.borderRadius*d),this.checkGLError(s,"resize: after uniform updates");const S=performance.now();this.lastTime=S;const O=(S-this.startTime)*.001;this.render(O)}autoResize(t){this.observer&&this.observer.disconnect(),this.observer=new ResizeObserver(()=>{const e=t.getBoundingClientRect();this.resize(e.width,e.height)}),this.observer.observe(t)}fadeIn(){if(this.disposed)throw new Error("Motion instance has been disposed.");return new Promise((t,e)=>{const r=this.canvas.animate([{opacity:0,transform:"scale(1.2)"},{opacity:1,transform:"scale(1)"}],{duration:300,easing:"ease-out",fill:"forwards"});r.onfinish=()=>t(),r.oncancel=()=>e("canceled")})}fadeOut(){if(this.disposed)throw new Error("Motion instance has been disposed.");return new Promise((t,e)=>{const r=this.canvas.animate([{opacity:1,transform:"scale(1)"},{opacity:0,transform:"scale(1.2)"}],{duration:300,easing:"ease-in",fill:"forwards"});r.onfinish=()=>t(),r.oncancel=()=>e("canceled")})}checkGLError(t,e){let r=t.getError();if(r!==t.NO_ERROR){for(console.group(`🔴 WebGL Error in ${e}`);r!==t.NO_ERROR;){const s=this.getGLErrorName(t,r);console.error(`${s} (0x${r.toString(16)})`),r=t.getError()}console.groupEnd()}}getGLErrorName(t,e){switch(e){case t.INVALID_ENUM:return"INVALID_ENUM";case t.INVALID_VALUE:return"INVALID_VALUE";case t.INVALID_OPERATION:return"INVALID_OPERATION";case t.INVALID_FRAMEBUFFER_OPERATION:return"INVALID_FRAMEBUFFER_OPERATION";case t.OUT_OF_MEMORY:return"OUT_OF_MEMORY";case t.CONTEXT_LOST_WEBGL:return"CONTEXT_LOST_WEBGL";default:return"UNKNOWN_ERROR"}}setupGL(){const t=this.canvas.getContext("webgl2",{antialias:!1,alpha:!0});if(!t)throw new Error("WebGL2 is required but not available.");const e=ct(t,ht,dt);this.checkGLError(t,"setupGL: after createProgram");const r=t.createVertexArray();t.bindVertexArray(r),this.checkGLError(t,"setupGL: after VAO creation");const s=this.canvas.width||2,a=this.canvas.height||2,{positions:i,uvs:R}=tt(s,a,this.options.borderWidth,this.options.glowWidth),p=t.createBuffer();t.bindBuffer(t.ARRAY_BUFFER,p),t.bufferData(t.ARRAY_BUFFER,i,t.STATIC_DRAW);const v=t.getAttribLocation(e,"aPosition");t.enableVertexAttribArray(v),t.vertexAttribPointer(v,2,t.FLOAT,!1,0,0),this.checkGLError(t,"setupGL: after position buffer setup");const d=t.createBuffer();t.bindBuffer(t.ARRAY_BUFFER,d),t.bufferData(t.ARRAY_BUFFER,R,t.STATIC_DRAW);const w=t.getAttribLocation(e,"aUV");t.enableVertexAttribArray(w),t.vertexAttribPointer(w,2,t.FLOAT,!1,0,0),this.checkGLError(t,"setupGL: after UV buffer setup");const G=t.getUniformLocation(e,"uResolution"),D=t.getUniformLocation(e,"uTime"),U=t.getUniformLocation(e,"uBorderWidth"),I=t.getUniformLocation(e,"uGlowWidth"),k=t.getUniformLocation(e,"uBorderRadius"),S=t.getUniformLocation(e,"uColors"),O=t.getUniformLocation(e,"uGlowExponent"),M=t.getUniformLocation(e,"uGlowFactor");t.useProgram(e),t.uniform1f(U,this.options.borderWidth),t.uniform1f(I,this.options.glowWidth),t.uniform1f(k,this.options.borderRadius),this.options.mode==="dark"?(t.uniform1f(O,2),t.uniform1f(M,1.8)):(t.uniform1f(O,1),t.uniform1f(M,1));const u=(this.options.colors||lt).map(ut);for(let h=0;h<u.length;h++)t.uniform3f(t.getUniformLocation(e,`uColors[${h}]`),...u[h]);this.checkGLError(t,"setupGL: after uniform setup"),t.bindVertexArray(null),t.bindBuffer(t.ARRAY_BUFFER,null),this.glr={gl:t,program:e,vao:r,positionBuffer:p,uvBuffer:d,uResolution:G,uTime:D,uBorderWidth:U,uGlowWidth:I,uBorderRadius:k,uColors:S}}render(t){if(!this.glr)return;const{gl:e,program:r,vao:s,uTime:a}=this.glr;e.useProgram(r),e.bindVertexArray(s),e.uniform1f(a,t),e.disable(e.DEPTH_TEST),e.disable(e.CULL_FACE),e.disable(e.BLEND),e.clearColor(0,0,0,0),e.clear(e.COLOR_BUFFER_BIT),e.drawArrays(e.TRIANGLES,0,24),this.checkGLError(e,"render: after draw call"),e.bindVertexArray(null)}greet(){console.log("%c🌈 ai-motion 0.4.8 🌈","background: linear-gradient(90deg, #39b6ff, #bd45fb, #ff5733, #ffd600); color: white; text-shadow: 0 0 2px rgba(0, 0, 0, 0.2); font-weight: bold; font-size: 1em; padding: 2px 12px; border-radius: 6px;")}}(function(){try{if(typeof document<"u"){var o=document.createElement("style");o.appendChild(document.createTextNode(`._wrapper_1ooyb_1 {
	position: fixed;
	inset: 0;
	z-index: 2147483641; /* 确保在所有元素之上，除了 panel */
	cursor: wait;
	overflow: hidden;

	display: none;
}

._wrapper_1ooyb_1._visible_1ooyb_11 {
	display: block;
}
/* AI 光标样式 */
._cursor_1dgwb_2 {
	position: absolute;
	width: var(--cursor-size, 75px);
	height: var(--cursor-size, 75px);
	pointer-events: none;
	z-index: 10000;
}

._cursorBorder_1dgwb_10 {
	position: absolute;
	width: 100%;
	height: 100%;
	background: linear-gradient(45deg, rgb(57, 182, 255), rgb(189, 69, 251));
	mask-image: url("data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20100%20100'%20fill='none'%3e%3cg%3e%3cpath%20d='M%2015%2042%20L%2015%2036.99%20Q%2015%2031.99%2023.7%2031.99%20L%2028.05%2031.99%20Q%2032.41%2031.99%2032.41%2021.99%20L%2032.41%2017%20Q%2032.41%2012%2041.09%2016.95%20L%2076.31%2037.05%20Q%2085%2042%2076.31%2046.95%20L%2041.09%2067.05%20Q%2032.41%2072%2032.41%2062.01%20L%2032.41%2057.01%20Q%2032.41%2052.01%2023.7%2052.01%20L%2019.35%2052.01%20Q%2015%2052.01%2015%2047.01%20Z'%20fill='none'%20stroke='%23000000'%20stroke-width='6'%20stroke-miterlimit='10'%20style='stroke:%20light-dark(rgb(0,%200,%200),%20rgb(255,%20255,%20255));'/%3e%3c/g%3e%3c/svg%3e");
	mask-size: 100% 100%;
	mask-repeat: no-repeat;

	transform-origin: center;
	transform: rotate(-135deg) scale(1.2);
	margin-left: -10px;
	margin-top: -18px;
}

._cursorFilling_1dgwb_25 {
	position: absolute;
	width: 100%;
	height: 100%;
	background: url("data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20100%20100'%3e%3cdefs%3e%3c/defs%3e%3cg%20xmlns='http://www.w3.org/2000/svg'%20style='filter:%20drop-shadow(light-dark(rgba(0,%200,%200,%200.4),%20rgba(237,%20237,%20237,%200.4))%203px%204px%204px);'%3e%3cpath%20d='M%2015%2042%20L%2015%2036.99%20Q%2015%2031.99%2023.7%2031.99%20L%2028.05%2031.99%20Q%2032.41%2031.99%2032.41%2021.99%20L%2032.41%2017%20Q%2032.41%2012%2041.09%2016.95%20L%2076.31%2037.05%20Q%2085%2042%2076.31%2046.95%20L%2041.09%2067.05%20Q%2032.41%2072%2032.41%2062.01%20L%2032.41%2057.01%20Q%2032.41%2052.01%2023.7%2052.01%20L%2019.35%2052.01%20Q%2015%2052.01%2015%2047.01%20Z'%20fill='%23ffffff'%20stroke='none'%20style='fill:%20%23ffffff;'/%3e%3c/g%3e%3c/svg%3e");
	background-size: 100% 100%;
	background-repeat: no-repeat;

	transform-origin: center;
	transform: rotate(-135deg) scale(1.2);
	margin-left: -10px;
	margin-top: -18px;
}

._cursorRipple_1dgwb_39 {
	position: absolute;
	width: 100%;
	height: 100%;
	pointer-events: none;
	margin-left: -50%;
	margin-top: -50%;

	&::after {
		content: '';
		opacity: 0;
		position: absolute;
		inset: 0;
		border: 4px solid rgba(57, 182, 255, 1);
		border-radius: 50%;
	}
}

._cursor_1dgwb_2._clicking_1dgwb_57 ._cursorRipple_1dgwb_39::after {
	animation: _cursor-ripple_1dgwb_1 300ms ease-out forwards;
}

@keyframes _cursor-ripple_1dgwb_1 {
	0% {
		transform: scale(0);
		opacity: 1;
	}
	100% {
		transform: scale(2);
		opacity: 0;
	}
}`)),document.head.appendChild(o)}}catch(t){console.error("vite-plugin-css-injected-by-js",t)}})();function pt(){const o=["dark","dark-mode","theme-dark","night","night-mode"],t=document.documentElement,e=document.body||document.documentElement;for(const s of o)if(t.classList.contains(s)||e!=null&&e.classList.contains(s))return!0;const r=t.getAttribute("data-theme");return!!(r!=null&&r.toLowerCase().includes("dark"))}function gt(o){const t=/rgba?\((\d+),\s*(\d+),\s*(\d+)/.exec(o);return t?{r:parseInt(t[1]),g:parseInt(t[2]),b:parseInt(t[3])}:null}function ot(o,t=128){if(!o||o==="transparent"||o.startsWith("rgba(0, 0, 0, 0)"))return!1;const e=gt(o);return e?.299*e.r+.587*e.g+.114*e.b<t:!1}function mt(){const o=window.getComputedStyle(document.documentElement),t=window.getComputedStyle(document.body||document.documentElement),e=o.backgroundColor,r=t.backgroundColor;return ot(r)?!0:r==="transparent"||r.startsWith("rgba(0, 0, 0, 0)")?ot(e):!1}function wt(){try{return!!(pt()||mt())}catch(o){return console.warn("Error determining if page is dark:",o),!1}}const vt="_wrapper_1ooyb_1",bt="_visible_1ooyb_11",H={wrapper:vt,visible:bt},Lt="_cursor_1dgwb_2",_t="_cursorBorder_1dgwb_10",Et="_cursorFilling_1dgwb_25",At="_cursorRipple_1dgwb_39",yt="_clicking_1dgwb_57",B={cursor:Lt,cursorBorder:_t,cursorFilling:Et,cursorRipple:At,clicking:yt};var P,c,g,m,T,C,F,rt,Z;class Rt extends EventTarget{constructor(){super();x(this,F);l(this,"shown",!1);l(this,"wrapper",document.createElement("div"));l(this,"motion",null);x(this,P,!1);x(this,c,document.createElement("div"));x(this,g,0);x(this,m,0);x(this,T,0);x(this,C,0);this.wrapper.id="page-agent-runtime_simulator-mask",this.wrapper.className=H.wrapper,this.wrapper.setAttribute("data-browser-use-ignore","true"),this.wrapper.setAttribute("data-page-agent-ignore","true");try{const i=new ft({mode:wt()?"dark":"light",styles:{position:"absolute",inset:"0"}});this.motion=i,this.wrapper.appendChild(i.element),i.autoResize(this.wrapper)}catch(i){console.warn("[SimulatorMask] Motion overlay unavailable:",i)}this.wrapper.addEventListener("click",i=>{i.stopPropagation(),i.preventDefault()}),this.wrapper.addEventListener("mousedown",i=>{i.stopPropagation(),i.preventDefault()}),this.wrapper.addEventListener("mouseup",i=>{i.stopPropagation(),i.preventDefault()}),this.wrapper.addEventListener("mousemove",i=>{i.stopPropagation(),i.preventDefault()}),this.wrapper.addEventListener("wheel",i=>{i.stopPropagation(),i.preventDefault()}),this.wrapper.addEventListener("keydown",i=>{i.stopPropagation(),i.preventDefault()}),this.wrapper.addEventListener("keyup",i=>{i.stopPropagation(),i.preventDefault()}),N(this,F,rt).call(this),document.body.appendChild(this.wrapper),N(this,F,Z).call(this);const e=i=>{const{x:R,y:p}=i.detail;this.setCursorPosition(R,p)},r=()=>{this.triggerClickAnimation()},s=()=>{this.wrapper.style.pointerEvents="none"},a=()=>{this.wrapper.style.pointerEvents="auto"};window.addEventListener("PageAgent::MovePointerTo",e),window.addEventListener("PageAgent::ClickPointer",r),window.addEventListener("PageAgent::EnablePassThrough",s),window.addEventListener("PageAgent::DisablePassThrough",a),this.addEventListener("dispose",()=>{window.removeEventListener("PageAgent::MovePointerTo",e),window.removeEventListener("PageAgent::ClickPointer",r),window.removeEventListener("PageAgent::EnablePassThrough",s),window.removeEventListener("PageAgent::DisablePassThrough",a)})}setCursorPosition(e,r){n(this,P)||(f(this,T,e),f(this,C,r))}triggerClickAnimation(){n(this,P)||(n(this,c).classList.remove(B.clicking),n(this,c).offsetHeight,n(this,c).classList.add(B.clicking))}show(){var e,r;this.shown||n(this,P)||(this.shown=!0,(e=this.motion)==null||e.start(),(r=this.motion)==null||r.fadeIn(),this.wrapper.classList.add(H.visible),f(this,g,window.innerWidth/2),f(this,m,window.innerHeight/2),f(this,T,n(this,g)),f(this,C,n(this,m)),n(this,c).style.left=`${n(this,g)}px`,n(this,c).style.top=`${n(this,m)}px`)}hide(){var e,r;!this.shown||n(this,P)||(this.shown=!1,(e=this.motion)==null||e.fadeOut(),(r=this.motion)==null||r.pause(),n(this,c).classList.remove(B.clicking),setTimeout(()=>{this.wrapper.classList.remove(H.visible)},800))}dispose(){var e;f(this,P,!0),console.log("dispose SimulatorMask"),(e=this.motion)==null||e.dispose(),this.wrapper.remove(),this.dispatchEvent(new Event("dispose"))}}P=new WeakMap,c=new WeakMap,g=new WeakMap,m=new WeakMap,T=new WeakMap,C=new WeakMap,F=new WeakSet,rt=function(){n(this,c).className=B.cursor;const e=document.createElement("div");e.className=B.cursorRipple,n(this,c).appendChild(e);const r=document.createElement("div");r.className=B.cursorFilling,n(this,c).appendChild(r);const s=document.createElement("div");s.className=B.cursorBorder,n(this,c).appendChild(s),this.wrapper.appendChild(n(this,c))},Z=function(){if(n(this,P))return;const e=n(this,g)+(n(this,T)-n(this,g))*.2,r=n(this,m)+(n(this,C)-n(this,m))*.2,s=Math.abs(e-n(this,T));s>0&&(s<2?f(this,g,n(this,T)):f(this,g,e),n(this,c).style.left=`${n(this,g)}px`);const a=Math.abs(r-n(this,C));a>0&&(a<2?f(this,m,n(this,C)):f(this,m,r),n(this,c).style.top=`${n(this,m)}px`),requestAnimationFrame(()=>N(this,F,Z).call(this))};export{Rt as SimulatorMask};
